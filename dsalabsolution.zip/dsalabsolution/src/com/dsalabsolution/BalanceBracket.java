package com.dsalabsolution;

import java.util.Stack;

public class BalanceBracket {
	
	static String brackets="([[{}]])";
//	static String brackets="()[][]{}";
//	static String brackets="()][{}";
//	static String brackets="[]{}()";

	
	public static void main(String[] args) {
		// TODO Auto-generated constructor stub
		Boolean result;
		result=BracketsBalance(brackets);
		if(result)
			System.out.println("The entered string has Balanced Brackets.");
		else
			System.out.println("The entered string do not contain Balanced Brackets.");
			
	}
	
	static Boolean BracketsBalance(String brackets) {
		// TODO Auto-generated constructor stub
		Stack<Character> stack = new Stack<Character>();
		for (int i=0; i<brackets.length(); i++) {
			char character = brackets.charAt(i);
			
			if (character =='(' || character =='[' || character =='{') {
				stack.push(character);
				continue;
			}
			
			if (stack.isEmpty())
				return false;
			
			char c;
			
			switch (character){
			
			case '}':
				c= stack.pop();
				if (c == '(' || c == '[')
					return false;
				break;
			
			case ')':
				c= stack.pop();
				if (c == '{' || c == '[')
					return false;
				break;
				
			case ']':
				c= stack.pop();
				if (c == '(' || c == '{')
					return false;
				break;
			}
		}
		
		return (stack.isEmpty());
		
	}
	
}
