package com.dsalabsolution;

import java.util.ArrayList;

public class LongPath {

	static class Node {
		Node leftNode,rightNode;
		int nodeAdd;
	}
		
	static Node newNode(int nodeAdd) {
		Node test=new Node();
		
		test.nodeAdd=nodeAdd;
		test.leftNode=null;
		test.rightNode=null;
		return test;
	}
	
	public static ArrayList<Integer> LongPath(Node root){
		if (root==null) {
			ArrayList<Integer> output = new ArrayList<>();
			return output;
		}
		
		ArrayList<Integer> rightNode = LongPath(root.rightNode);
		ArrayList<Integer> leftNode = LongPath(root.leftNode);
		
		if (rightNode.size() < leftNode.size()) {
			leftNode.add(root.nodeAdd);
		}
		else {
			rightNode.add(root.nodeAdd);
		}
		return (leftNode.size() > rightNode.size() ? leftNode : rightNode);
	}
	
	
	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Node root = newNode(100);
		root.rightNode = newNode(130);
		root.leftNode = newNode(20);
		root.rightNode.rightNode = newNode(140);
		root.rightNode.leftNode = newNode(110);
//		root.rightNode.leftNode.leftNode = newNode(45);
//		root.rightNode.leftNode.leftNode.leftNode = newNode(50);
		root.leftNode.rightNode = newNode(50);
		root.leftNode.leftNode = newNode(10);
		root.leftNode.leftNode.leftNode = newNode(5);
		
		ArrayList<Integer> output = LongPath(root);
		int size = output.size();
		
		System.out.println(output.get(size-1));
		for (int i = size - 2; i >= 0; i--) {
			System.out.println(" -> " + output.get(i));
		}
	}

	

}
